 var pre=document.getElementById('loading');
  function myfun(){
    pre.style.display='none';  
    
  }